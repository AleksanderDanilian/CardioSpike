import numpy as np #для работы с данными
import pandas as pd
from keras.models import load_model # Загрузка модели
import os
import json

def model_work(path):
    model = load_model('cardio_spike.hdf5',compile=False)       #Загружаем модель НС
    data = pd.read_csv(path, names=['id', 'time', 'x'], header=None, sep=',')
    data.drop(axis=0, index=0, columns=None, inplace=True)
    data.drop(columns='x', inplace=True)
    data.reset_index(drop=True, inplace=True)
    data.time = data.time.astype(int)
    data.head()
    indexes  = data['id'].unique()
    fin = []
    for i in indexes:
        temp = data[data['id'] == i]
        if len(temp)!=0:
            fin.append(temp)
        final_x = []
        for i in fin:
            final_x.append(i['time'])
            
    x_intervals = []
    for i in range(len(final_x)):
        arr_x = np.array(final_x[i], dtype='int')
        t = arr_x[1:] - arr_x[:-1]
        t = np.insert(t, 0, 0)
        x_intervals.append(t)
    final_x = x_intervals

    x_intervals1 = []
    for i in range(len(final_x)):
        arr_x = np.array(final_x[i], dtype='int')
        t = arr_x[1:] - arr_x[:-1]
        t = np.insert(t, 0, 0)
        x_intervals1.append(t)
    final_x = x_intervals1
    
    xVal1 = []
    for i in range(len(final_x)):                                            
        arr_x = np.array(final_x[i], dtype='float')
        xVal1.append(arr_x)

    length= 15    #Длина окна
    stride=1      #Шаг смещения
    final_pred = []
    for i in range(len(xVal1)):
        xVal = []
        prediction=[]
        iteration = 0
        count = 0                                              
        arr_x = np.array(xVal1[i], dtype='float')
        for j in range(len(arr_x)):                             
            wx = arr_x[iteration+stride:iteration+length+1]            
            iteration+=1
            if len(wx)==length:                                      
                xVal.append(wx)                                     
            else:
                continue
        for k in xVal:
            pred = model.predict(np.reshape(k, (-1, 15)))
            if pred > 0.6:
                pred = 1
            else:
                pred = 0
            prediction.append(pred)
        prediction = [0,0,0,0,0,0,0,0]+prediction+[0,0,0,0,0,0,0]
        prediction = np.reshape(prediction, (len(prediction), ))
        final_pred.append(prediction)
    final_pred1 = [item for sublist in final_pred for item in sublist]
    data['y'] = final_pred1
    fpath = './static/results/result.csv'
    data.to_csv(fpath, index=False)

    x_graphs = [item for sublist in x_intervals for item in sublist]
    data['x'] = x_graphs
    data['y'][data['y']==1]=data['x']
    graphs = []
    for i in indexes:
        temp = data[['time','x','y']][data['id'] == i]
        if len(temp)!=0:
            graphs.append(temp)

    graphs1 = []
    for i in graphs:
        t = i.values.tolist()
        graphs1.append(t)
        
    with open('./static/graphs.json', 'w', encoding='utf-8') as f:
        json.dump(graphs1, f, ensure_ascii=False, indent=4)



