from flask import Flask, render_template, request, redirect, url_for  
from werkzeug.utils import secure_filename 
import os
import openpyxl
from flask_cors import CORS
from flask import send_from_directory
from model import model_work
import json



UPLOAD_FOLDER = 'static/upload/'
ALLOWED_EXTENSIONS = set(['csv'])
DOWNLOAD_FOLDER = 'static/results/'

  
app = Flask(__name__)  
CORS(app)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.config['FOLDER_WIT_FILE'] = DOWNLOAD_FOLDER
# def allowed_file(filename):
#     return '.' in filename and \
#            filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS
             
@app.route('/')              
@app.route('/add', methods=['GET', 'POST'])       
def spikes_add():
    if request.method == 'POST':
        if request.files['file']:
            file = request.files['file']
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))                      
            return redirect(url_for('result'))
        else:
            return render_template('spikes_add.html')         
    else:  
        return render_template('spikes_add.html')
      
@app.route("/result/", methods=['GET'])  
def result():  
    try:
        path = './static/upload/'
        for file in os.listdir(path):
            if file.endswith(".csv"):
                filename = file
                path1 = path+filename
        model_work(path1)
        return render_template('spikes_result.html')  
    except:
        return render_template('error.html')

@app.route('/download/<path:filename>', methods=['GET', 'POST'])
def download(filename):
    directory = os.path.join(app.root_path, app.config['FOLDER_WIT_FILE'])
    return send_from_directory(directory=directory, filename=filename)

if __name__ == '__main__':  
    app.debug = True  
    app.run(port=14999)